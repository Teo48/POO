public class Task3 {
    public static void main(String [] args) {
        float [] v = new float[4];

        for (int i = 0 ; i < 4 ; ++i) {
            v[i] = (float)Math.PI + i;
        }

        Polygon p = new Polygon(v, 2);
        for (int i = 0 ; i < p.points.length ; ++i) {
            p.points[i].print(p.points[i]);
        }
    }
}
